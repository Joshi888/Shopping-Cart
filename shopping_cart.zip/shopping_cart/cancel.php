<?php
session_start();
if(isset($_POST["cancel_return"]))
{
	?>
	<script>
		alert("Are You Sure You Want To Exit");
		window.open("index.php","_self");
	</script>
	<?php
	//header("location:index.php");
}

?>