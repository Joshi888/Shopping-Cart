<?php
ob_start();
require_once("include/dbcon.php");
require_once("include/function.php");

$errorMsg = "";
$rname = trim($_POST["rname"]);
$remail = trim($_POST["remail"]);
$rpassword = trim($_POST["rpassword"]);
$rmobile = trim($_POST["rmobile"]);

	if(empty($rname))
	{
		$errorMsg .= "<li>Name Is Required<li>";
	}
	else
	{
		$rname = $rname;
	}

	if(empty($remail))
	{
		$errorMsg .= "<li>Email Is Required</li>";
	}
	else
	{
		$remail = filterEmail($remail);
		if($remail == FALSE)
		{
			$errorMsg .= "<li>Invalid Email</li>";
		}
	}

	if(empty($rpassword))
	{
		$errorMsg = "<li>Password Is Required";
	}
	else
	{
		$rpassword = password_hash($rpassword, PASSWORD_DEFAULT);
	}

	if(empty($rmobile))
	{
		$errorMsg = "<li>Mobile Is Required</li>";
	}
	else
	{
		$rmobile = $rmobile;
	}

	if(empty($errorMsg))
	{
		$qry = $db->prepare("SELECT email FROM users WHERE email=?");
		$qry->bindparam(1,$email);
		$qry->execute();

		if($qry->rowCount()>0)
		{
			echo json_encode(['code'=>400,'msg'=>'Email Already Exist'])
			exit();
		}
		else
		{
			$stmt = $db->prepare("INSERT INTO users(name,email,password,mobile) VALUES(:name, :email, :password, :mobile");
			$stmt->execute(array(':name'=>$rname, ':email'=>$remail, ':password'=>$rpassword, ':mobile'=>$rmobile));				
			$affected_rows = $stmt->rowCount();
			if($affected_rows == 1)
			{
				echo json_encode(['code'=>200, 'msg'=>'Successfully Signup']);
			}
			else
			{
				echo json_encode(['code'=>400]);
			}
		}
	}
	else
	{
		echo json_encode(['code'=>404,'msg'=>$errorMsg]);
	}

?>