$(document).ready(function()
{
	//on click signup it will hide login from & display registration form//
	$("#signup").click(function()
	{
		$("#loginContainer").slideUp("slow",function()
		{
			$("#signupContainer").slideDown("slow");
		});
	});
	//on click signin it will hide registration from & display login form//
	$("#signin").click(function()
	{
		$("#signupContainer").slideUp("slow",function()
		{
			$("#loginContainer").slideDown("slow");
		});
	});

})