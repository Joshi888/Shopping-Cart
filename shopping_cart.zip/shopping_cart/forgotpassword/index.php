<!DOCTYPE html>
<html>
<head>
	<title>Login Form And Registration Form</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<script src="jquery2.js"></script>
	<script src="script.js"></script>
</head>
<body>
	<div id="wrapper">
		<!--Created div first login form-->
		<div id="loginContainer">
			<form id="loginForm" method="post">
				<h3>Members Login Page</h3>
				<div class="display-error" style="display:none;"></div>
				<input type="email" name="lemail" placeholder="Enter Email">
				<input type="password" name="lpassword" placeholder="Enter Password">
				<input type="submit" value="Sign In">
				<p><a href="#">Forget Password</a></p>
				<p id="bottom">Create an Account<a href="#" id="signup">&nbsp;SignUp</a></p>
			</form>
		</div>
		<!--end first div-->
		<!--open second div-->
		<div id="signupContainer">
			<form id="registerfrm" method="post">
				<h3>New Member Sign Up</h3>
				<div class="display-error" style="display:none;"></div>
				<input type="text" name="rname" placeholder="Enter name" required>
				<input type="email" name="	" placeholder="Enter email" required>
				<input type="password" name="rpassword" placeholder="Enter Password" required>
				<input type="text" name="rmobile" maxlength="10" pattern="[0-9]{10}" placeholder="Mobile number" required>
				<input type="submit" value="Create Your Account">
				<p id="bottom">Alredy have an account?<a href="#" id="signin">SignIn</a></p>		
			</form>
		</div>
	</div>
	<script>
		$(document).ready(function()
		{
			$("#loginForm").submit(function()
			{
				var data = $("#loginForm").serialize();
				checkRecords(data);
				return false;
			});
			function checkRecords(data)
			{
				$.ajax
				({
					url: 'loginProcess.php',
					data :data,
					type :'post',
					datatype:'json',
					success :function(data)
					{
						if(data.code == 200)
						{
							alert("You Have Successfully Login");
							window.location='dashboard.php';
						}
						else
						{
							$(".display-error").html("<ul>"+data.msg+"</ul>");
							$(".display-error").css("display","block");
						}
					},
					error: function()
					{
						alert("Operation Failed");
					}
				});
			}
		});
	</script>
<!--sign up form-->
	<script>
		$(document).ready(function()
		{
			$("#registerfrm").submit(function()
			{
				var data = $("#registerfrm").serialize();
				signupRecords(data);
				return false;
			});
			function signupRecords(data)
			{
				$.ajax
				({
					url: 'signupProcess.php',
					data :data,
					type :'post',
					datatype:'json',
					success :function(data)
					{
						if(data.code == 200)
						{
							alert("You Have Successfully Sign Up \n Please Login Now");
							setTimeout(function()
							{
								location.reload();
							}, 1000 );
						}
						else
						{
							$(".display-error").html("<ul>"+data.msg+"</ul>");
							$(".display-error").css("display","block");
						}
					},
					error: function(jqXHR,exception)
					{
						console.log(jqXHR);
					}
				});
			}
		});
	</script>
</body>